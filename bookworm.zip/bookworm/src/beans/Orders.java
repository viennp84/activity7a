package beans;

import java.util.ArrayList;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.inject.Inject;

import business.OrderBusinessInterface;


/*
 * CST235
 * Vien Nguyen
 * This is the orders class,
 * The class has the attributes of an order list.
 * */
@ManagedBean
@ViewScoped
public class Orders {
	
	//Call Order Business Service
	@Inject
	OrderBusinessInterface service;
		//A list of orders.
		List<Order> orders = new ArrayList<Order>();

		public Orders() {
	
		}
		public List<Order> getOrders() {
			return orders;
		}
		public void setOrders(List<Order> orders) {
			this.orders = orders;
		}

}
