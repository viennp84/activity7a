package business;

import java.util.List;

import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import beans.Bible;
import data.BibleDataService;

/*Vien Nguyen
 * CST235 Benchmark
 * 
 * This is the Rests service class, 
 * will provide the communicating ports for outside services
 * */

@RequestScoped
@Path("bibles")
@Produces({ "application/xml", "application/json" })
@Consumes({ "application/xml", "application/json" })
public class RestBible {
	
	//Initiate and call Data Access Interface
	@Inject
	BibleDataService bibleDataService;
	
	//Get the bible list by getting json format
	@GET 
	@Path("/getjson")
	@Produces(MediaType.APPLICATION_JSON)
	public List<Bible> getBiblesAsJson(){
		return bibleDataService.findAll();
	}
	
	//Get the verse
	@GET 
	@Path("/searchVerse/{keyword}")
	@Produces(MediaType.APPLICATION_JSON)
	public List<Bible> searchVerse(@PathParam ("keyword") String keyword ){
		Bible bible = new Bible();
		bible.setVtext(keyword);
		return bibleDataService.findVerse(bible);
	}
	
	//Given a word, the service will return the number of occurrences of that word
	@GET 
	@Path("/getWordOccurences/{keyword}")
	@Produces(MediaType.APPLICATION_JSON)
	public Response getWordOccurences(@PathParam ("keyword") String keyword ){
		Bible bible = new Bible();
		bible.setVtext(keyword);
		return bibleDataService.getWordCount(bible);
	}
		
}
