package business;
import java.util.List;
import javax.annotation.Resource;
import javax.ejb.EJB;
import javax.ejb.Local;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.enterprise.inject.Alternative;
import javax.faces.bean.ViewScoped;
import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.JMSException;
import javax.jms.MessageProducer;
import javax.jms.ObjectMessage;
import javax.jms.Queue;
import javax.jms.Session;
import javax.jms.TextMessage;

import beans.Order;
import data.OrderDataService;

/**
 * OrdersBusinessService.cs Author: Vien Nguyen Session Bean implementation
 * class OrdersBusinessService
 */
@Stateless
@Local(OrderBusinessInterface.class)
@LocalBean
@Alternative

@ViewScoped
public class OrdersBusinessService implements OrderBusinessInterface {
	//Declare Order data service from business data layer
	@EJB
	OrderDataService orderDataService;
	
	//Initiate the mapper
	@Resource(mappedName = "java:/ConnectionFactory")
	private ConnectionFactory connectionFactory;
	//Initiate the message queue
	@Resource(mappedName = "java:/jms/queue/Order")
	private Queue queue;

	/**
	 * Default constructor.
	 */
	public OrdersBusinessService() {
	}
	//Get the list of order by call the method findAll order in the OrderDataService.
	@Override
	public List<Order> getOrders() {
		return orderDataService.findAll();
	}

	//Send the message
	@Override
	public void sendOrder(Order order) {
		// Send a Message for an Order
		try {
			//Get a connection and session to the JMSConnect Factory
			Connection connection = connectionFactory.createConnection();
			Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
			
			//Create a Message Product for sending mesage to the Queue
			MessageProducer messageProducer = session.createProducer(queue);
			//Create and send text message
			TextMessage message1 = session.createTextMessage();
			message1.setText("This is test message");
			messageProducer.send(message1);
			//Create and send an Object Message (with the Order)
			ObjectMessage message2 = session.createObjectMessage();
			message2.setObject(order);
			messageProducer.send(message2);
			connection.close();
		} catch (JMSException e) {
			e.printStackTrace();
		}
	}
	public OrderDataService getOrderDataService() {
		return orderDataService;
	}

}
