package business;

import java.util.List;

import javax.ejb.Local;
import beans.*;
/**
 * OrderBusinessInterface.cs
 * Author: Vien Nguyen
 * OrderBusinessInterface defines the interface used to call the its implementations.
 */
@Local
public interface OrderBusinessInterface {
	
	//Get the list of the orders
	public List<Order> getOrders();
	//Send the order
	public void sendOrder(Order order);
}
