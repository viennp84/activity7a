package business;


import java.util.List;

import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import beans.Order;
import data.DataAccessInterface;

/*Vien Nguyen
 * CST235 TUE-THURS
 * 
 * This is the Rests service class, 
 * will provide the communicating ports for outside services
 * */

@RequestScoped
@Path("/orders")
@Produces({"application/xml", "application/json"})
@Consumes({"application/xml", "application/json"})
public class OrdersRestService  {
	
	
	//Initiate and call Order business interface
	@Inject
	OrderBusinessInterface service;
	//Initiate and call Data Access Interface
	@Inject
	DataAccessInterface<Order> dataService;
	
	//Get the order list by getting json format
	@GET 
	@Path("/getjson")
	@Produces(MediaType.APPLICATION_JSON)
	public List<Order> getOrdersAsJson(){
		return service.getOrders();
	}
	//Get the order list by getting xml format
	@GET 
	@Path("/getxml")
	@Produces(MediaType.APPLICATION_XML)
	public Order[] getOrdersAsXml(){
		List<Order> orders = service.getOrders();
		return orders.toArray(new Order[orders.size()]);
	}
	//Insert an order 
	@POST
	@Path("/insertOrder")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Response insertOrderService(Order order){
		dataService.create(order);
		 return Response.ok(order).build();
	}
	//Delete an order by the order_id by passing an key id in the web service.
	@DELETE
	@Path("deleteOrder/{order_no}")
	@Produces(MediaType.APPLICATION_JSON)
	public String deleteOrder(@PathParam ("order_no") String order_no ) {
		Order o = new Order();
		o.setOrderNo(order_no);
		dataService.delete(o);
	    return "Order Deleted";
	}

}
